import acm.graphics.*;
import acm.program.*;
import acm.util.*;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class BreakoutCameron extends GraphicsProgram
{
	
	//width of game display
   private static final int WIDTH = 400; 
	
	//height of game display
   private static final int HEIGHT = 600; 
	
	//width of paddle
   private static final int PADDLE_WIDTH = 60; 
	
	//height of paddle
   private static final int PADDLE_HEIGHT = 10; 
	
	//offset of paddle up from the bottom
   private static final int PADDLE_Y_OFFSET = 30; 
	
	//number of bricks per row
   private static final int NBRICKS_PER_ROW = 10; 
	
	//number of rows of bricks
   private static final int NBRICK_ROWS = 10; 
	
	//separation between bricks
   private static final int BRICK_SEP = 4;
	
	//width of each brick (based on the dimensions of the game display)
   private static final int BRICK_WIDTH = WIDTH / NBRICKS_PER_ROW - BRICK_SEP;
	
	//height of brick
   private static final int BRICK_HEIGHT = 8;
	
	//radius of ball in pixels
   private static final int BALL_RADIUS = 6; 
	
	//offset of the top brick row from top
   private static final int BRICK_Y_OFFSET = 70; 
	
	//number of turns
   private static int NTURNS = 3;
	
	//the paddle
   private GRect paddle;
   
   //label
   private GLabel loser;
   
   private GLabel win;
   
   //label
   private GLabel turns;
   
   int bricks = 100;
	
	//the ball
   private GOval ball;
	
	//ball velocity in both directions (x-direction, and y-direction)
   private double vx, vy;
	
	//records the last x position of the mouse (see mouseMoved method)
   private double lastX;
	
	//used for mouse events (only moves the paddle every 5th mouse move)
   private int toggle = 0;
	
   //random number generator
   private RandomGenerator rgen = new RandomGenerator();
   /*
   public void keyPressed(KeyEvent e) {
      return;
   }
   public void keyReleased(KeyEvent e){
      return;  
   }
   public void keyTyped(KeyEvent e) {
      return;
   }  
   */    
	//main method -- called when the program is run
   public static void main(String[] args)
   {
      String[] sizeArgs = { "width=" + WIDTH, "height=" + HEIGHT };
      final BreakoutCameron b = new BreakoutCameron();
      final Key key = new Key(b.paddle);
      b.addKeyListener(key);
      b.setFocusable(true);
      b.start(sizeArgs);
   }
	//run method -- called indirectly from the main method
   public void run()
   {
      setup();
      play();
   }
	
	//setup method -- called from the run method
   public void setup()
   {
      createBricks();
      createPaddle();
      createBall();
   }
	
	//createBricks method -- called from the setup method
   public void createBricks()
   {
   	//make the bricks
      for(int x = 0; x < NBRICK_ROWS; x++)
      {
         for(int y = 0; y < NBRICKS_PER_ROW; y++)
         {
            GRect brick = new GRect((y * BRICK_WIDTH) + BRICK_SEP*y + BRICK_SEP/2, 
               						BRICK_Y_OFFSET + (BRICK_HEIGHT * x) + BRICK_SEP*x, 
               							BRICK_WIDTH, 
               								BRICK_HEIGHT);
            brick.setFilled(true);
            if(x == 0)
               brick.setColor(Color.RED);
            if(x == 1)
               brick.setColor(Color.YELLOW.darker());
            if(x == 2)
               brick.setColor(Color.ORANGE);
            if(x == 3)
               brick.setColor(Color.YELLOW.brighter());
            if(x == 4)
               brick.setColor(Color.GREEN.brighter());
            if(x == 5)
               brick.setColor(Color.GREEN.darker());
            if(x == 6)
               brick.setColor(Color.BLUE);
            if(x == 7)
               brick.setColor(Color.BLUE.darker());
            if(x == 8)
               brick.setColor(Color.MAGENTA);
            if(x == 9)
               brick.setColor(Color.MAGENTA.darker());
            add(brick);
         }
      }
   }
	
	//createPaddle method -- called from the setup method
   public void createPaddle()
   {
      paddle = new GRect(200, HEIGHT - PADDLE_Y_OFFSET, BRICK_WIDTH, BRICK_HEIGHT);
      paddle.setColor(Color.BLACK);
      add(paddle);
   }
	
	//createBall method -- called from the setup method
   public void createBall()
   {
      ball = new GOval(200, 400, BALL_RADIUS, BALL_RADIUS);
      ball.setColor(Color.BLACK);
      add(ball);
   }
	
	//play method -- called from the run method after setup
   public void play()
   {
      startTheBall();
      playBall();
   }
	
	//startTheBall method -- called from the play method
   public void startTheBall()
   {
      vx = rgen.nextDouble(.1, .3);
      if(rgen.nextBoolean(0.5))
         vx = -vy;
      vy = .3;
   }
	
	//playBall method -- called from the play method
   public void playBall()
   { 
      turns = new GLabel("Turns: " + NTURNS, 0, 600);
      turns.setFont("Seriff");
      turns.setColor(Color.BLACK);
      add(turns);
         
   
   	//continuous loop
      while(true)
      {
      	//move the ball
         ball.move(vx, vy);
      	//pause
         pause(1);
      	
         if(ball.getY() >= HEIGHT - BALL_RADIUS)
         {
            remove(ball);
            createBall();
            pause(1000);
            startTheBall();
            NTURNS = NTURNS - 1;
            turns.setLabel("Turns: " + NTURNS);
         }
         if(ball.getX() <= 0 + BALL_RADIUS)
         {
            vx = -vx;
         }
         if(ball.getX() >= WIDTH - BALL_RADIUS)
         {
            vx = -vx;
         }
         if(ball.getY() <= 0 + BALL_RADIUS)
         {
            vy = -vy;
         }
         if(NTURNS == 0)
         {
            loser = new GLabel("LOSER", 100, 300);
            loser.setFont(new Font("Seriff", Font.BOLD, 50));
            loser.setColor(Color.BLACK);
            add(loser);
            remove(paddle);
            remove(ball);
            break;
         }
      	
      	//check for collisions with bricks or paddle
         GObject collider = getCollidingObject();
      	
      	//if the ball collided with the paddle 
         if(collider == paddle)
         {
         	//reverse the y velocity
            vy = -vy;
         }
         //otherwise if the ball collided with a brick
         else if(collider instanceof GRect) 
         {
         	//reverse y velocity
            vy = -vy;
         	//remove the brick
            remove(collider);
            bricks = bricks - 1;
         }
         if(bricks == 0)
         {
            win = new GLabel("WINNER", 100, 300);
            win.setFont(new Font("Seriff", Font.BOLD, 50));
            win.setColor(Color.BLACK);
            add(win);
            remove(paddle);
            remove(ball);
         }
      }
   }
	
	//getCollidingObject -- called from the playBall method
	//discovers and returns the object that the ball collided with
   private GObject getCollidingObject()
   {
      if(getElementAt(ball.getX(), ball.getY()) != null)
         return getElementAt(ball.getX(), ball.getY());
      else if(getElementAt(ball.getX()+BALL_RADIUS*2, ball.getY()) != null)
         return getElementAt(ball.getX()+BALL_RADIUS*2, ball.getY());
      else if(getElementAt(ball.getX()+BALL_RADIUS*2, ball.getY()+BALL_RADIUS*2) != null)
         return getElementAt(ball.getX()+BALL_RADIUS*2, ball.getY()+BALL_RADIUS*2);
      else if(getElementAt(ball.getX(), ball.getY()+BALL_RADIUS*2) != null)
         return getElementAt(ball.getX(), ball.getY()+BALL_RADIUS*2);
      else	
         return null;
   }
		
	//mouseMoved method -- called by the mouseListener when the mouse is moved
	//anywhere within the boundaries of the run window
   private static final class Key extends KeyAdapter
   {
      final GRect paddle;
      
      public Key(GRect paddle) {
         this.paddle = paddle;
      }
      
      public void keyPressed(KeyEvent e)
      {
         System.out.println("Hello");
         if(e.getKeyCode() == KeyEvent.VK_RIGHT)
            paddle.move(20,0);
         if(e.getKeyCode() == KeyEvent.VK_LEFT)
            paddle.move(-20,0);
      }
   }
   /* 	//only move the paddle every 5th mouse event 
   	//otherwise the play slows every time the mouse moves
      if(toggle == 5)
      {
      	//get the x-coordinate of the mouse
         double eX = e.getX();
      	
      	//if the mouse moved to the right
         if(eX - lastX > 0)
         {
           	//if paddle is not already at the right wall
            if(paddle.getX() < WIDTH - PADDLE_WIDTH)
            {
            	//move to the right
               paddle.move(eX - lastX, 0);
            }
         }
         else //(if the mouse moved to the left)
         {
           	//if paddle is not already at the left wall
            if(paddle.getX() > 0)
            {
            	//move to the left
               paddle.move(eX - lastX, 0);
            }
         }
           	
           //record this mouse x position for next mouse event         	
         GPoint last = new GPoint(e.getPoint());
         lastX = last.getX();
      	
      	//reset toggle to 1 
         toggle = 1;
      }
      else
      {
      	//increment toggle by 1
      	//(when toggle gets to 5 the code will move the paddle 
      	// and reset toggle back to 1)
         toggle++;
      }*/
}