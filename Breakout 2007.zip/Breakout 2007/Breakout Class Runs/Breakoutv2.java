import acm.graphics.*;
import acm.program.*;
import acm.util.*;

import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class Breakoutv2 extends GraphicsProgram 
{
        
        //width of game display
   private static final int WIDTH = 400; 
        
        //height of game display
   private static final int HEIGHT = 600; 
        
        //width of paddle
   private static final int PADDLE_WIDTH = 60; 
        
        //height of paddle
   private static final int PADDLE_HEIGHT = 10; 
        
        //offset of paddle up from the bottom
   private static final int PADDLE_Y_OFFSET = 30; 
        
        //number of bricks per row
   private static final int NBRICKS_PER_ROW = 10; 
        
        //number of rows of bricks
   private static final int NBRICK_ROWS = 10; 
        
        //separation between bricks
   private static final int BRICK_SEP = 4; 
        
        //width of each brick (based on the dimensions of the game display)
   private static final int BRICK_WIDTH = WIDTH / NBRICKS_PER_ROW - BRICK_SEP;
        
        //height of brick
   private static final int BRICK_HEIGHT = 8;
        
        //radius of ball in pixels
   private static final int BALL_RADIUS = 6; 
        
        //offset of the top brick row from top
   private static final int BRICK_Y_OFFSET = 70; 
        
        //number of turns
   private static final int NTURNS = 3;
        
        //the paddle
   private GRect paddle;
        
        //the ball
   private GOval ball;
        
        //ball velocity in both directions (x-direction, and y-direction)
   private double vx, vy;
        
        //records the last x position of the mouse (see mouseMoved method)
   private double lastX;
        
        //used for mouse events (only moves the paddle every 5th mouse move)
   private int toggle = 0;
   
   private int scoreCount = 0;
   private int bricksLeft = 100;
   private int gameLives = 3;
   
   private GLabel score;
   private GLabel amountLeft;
   private GLabel win;
   private GLabel lives;
        
        //main method -- called when the program is run
   public static void main(String[] args)
   {
      String[] sizeArgs = { "width=" + WIDTH, "height=" + HEIGHT };
      new Breakoutv2().start(sizeArgs);
   }
        
        //run method -- called indirectly from the main method
   public void run()
   {
      score = new GLabel("Score: " + scoreCount);
      score.isVisible();
      score.setLocation(50.0, 50.0);
      add(score);
      
      lives = new GLabel("Lives: " + gameLives);
      lives.isVisible();
      lives.setLocation(150,50);
      add(lives);
      
      
      amountLeft = new GLabel("Bricks Left: " + bricksLeft);
      amountLeft.isVisible();
      amountLeft.setLocation(300.0, 50.0);
      add(amountLeft);
      
     setup();
      play();
   }
        
        //setup method -- called from the run method
   public void setup()
   {
      createBricks();
      createPaddle();
      createBall();
      addMouseListeners();
   }
        
        //createBricks method -- called from the setup method
   public void createBricks()
   {
           //make the bricks
      for(int x = 0; x < NBRICK_ROWS; x++)
      {
         for(int y = 0; y < NBRICKS_PER_ROW; y++)
         {
            GRect brick = new GRect((y * BRICK_WIDTH) + BRICK_SEP*y + BRICK_SEP/2, 
                                                               BRICK_Y_OFFSET + (BRICK_HEIGHT * x) + BRICK_SEP*x, 
                                                                       BRICK_WIDTH, 
                                                                               BRICK_HEIGHT);
            brick.setFilled(true);
                 
            if(x == 0 ||  x == 1)
               brick.setColor(Color.RED);
            if(x == 2 || x == 3)
               brick.setColor(Color.ORANGE);
            if(x == 4 || x == 5)
               brick.setColor(Color.YELLOW);
            if(x == 6 || x == 7)
               brick.setColor(Color.GREEN);
            if(x == 8 || x == 9)
               brick.setColor(Color.CYAN);
                                                 
            add(brick);
         }
      }
   }
        
        //createPaddle method -- called from the setup method
   public void createPaddle()
   {
   
      paddle = new GRect(WIDTH/2 - PADDLE_WIDTH/2, HEIGHT- PADDLE_Y_OFFSET -PADDLE_HEIGHT, PADDLE_WIDTH, PADDLE_HEIGHT);
   
      paddle.setFilled(true);
      add(paddle);
   
   
   
   
   }
        
        //createBall method -- called from the setup method
   public void createBall()
   {
      ball = new GOval(WIDTH/2 - BALL_RADIUS,HEIGHT/2- BALL_RADIUS, 2*BALL_RADIUS, 2*BALL_RADIUS);
      ball.setFilled(true);
      add(ball);
      
      
   }
        
        //play method -- called from the run method after setup
   public void play()
   {
      waitForClick();
      startTheBall();
      playBall();
   }
        
        //startTheBall method -- called from the play method
   public void startTheBall()
   {
           
      RandomGenerator rgen = new RandomGenerator();
      
      
      vy = 0.3;
      vx = rgen.nextDouble(.1, .4);
      if(rgen.nextBoolean(.5)) 
         vx = -vx;
      
      
      
      
      
      /******************************************/
        /*                                                        */
        /* create a random double between 1 and 3,*/
        /* (between 1.0 and 2.99) for vx          */
        /*                                                        */
        /* flip a coin for left or right direction*/
        /* (make vx positive or negative)             */
        /*                                                        */
        /* set initial y velocity to 3.0          */
        /*                                                        */
        /******************************************/
           
   }
        
        //playBall method -- called from the play method
   public void playBall()
   {
           //continuous loop
      while(true)
      {
              //move the ball
         ball.move(vx, vy);
              //pause
         pause(1);
                            //check for contact along the outer walls
              
          if(ball.getY() <= 0 - BALL_RADIUS)
         {
               
            vy = vy * -1;
         }
         else if(ball.getX() >= 400 - BALL_RADIUS)
         {
            vx = vx * -1;
         }
         else if(ball.getX() <= 0 - BALL_RADIUS)
         {
            vx = vx * -1;
         }
         else if(ball.getY() >= 600 - BALL_RADIUS)//Bottom - Loss
         {
            vy = vy * -1;
            
            gameLives--;
            lives.setLabel("Lives: " + gameLives);
            
            if(gameLives >= 1)
                {
                  remove(ball);
                  createBall();
                  waitForClick();
                  startTheBall();
                }
            else
                {
                  remove(ball);
                  remove(paddle);
                  
                  GLabel loss = new GLabel("Game Over",200,300);
                  loss.isVisible();
                  loss.setColor(Color.BLACK);
                  add(loss);
                  
                  pause(5000);
                  
                  gameLives = 3;
                  scoreCount = 0;
                  bricksLeft = 100;
                  remove(loss);
                  setup();
                  
                  waitForClick();
                  play();
                 }
                  
                  
                  
         }
               

      
      
         
         /**********************************************/
                /*                                                         */
                /* if ball contacts the floor,                          */
                /* reverse the y velocity                                       */
                /*                                                            */
                /* otherwise, if ball contacts the ceiling,          */
                /* reverse the y velocity                                       */
                /*                                                            */
                /* otherwise, if ball contacts the left wall, */
                /* reverse the x velocity                                       */
                /*                                                            */
                /* otherwise, if ball contacts the right wall,*/
                /* reverse the x velocity                                       */
                /*                                                            */
                /**********************************************/
      
              
              //check for collisions with bricks or paddle
         GObject collider = getCollidingObject();
              
              //if the ball collided with the paddle 
         if(collider == paddle)
         {
            int r;
            
            if(vx > 0)
            {
               if(ball.getX() < collider.getX() + (PADDLE_WIDTH / 2))
               {
                 
                  vx = -vx;
                  
                  
               }
               else
               {
                 
                  vx = vx;
                       
               }
            }
            else
            {
               if(ball.getX() > collider.getX() + (PADDLE_WIDTH / 2))
               {
                
                  vx = -vx;
               }
               else
               {
                  vx = vx;
               }
            }       
                
            vy = -vy;                      
                	
         //vy = -vy;
         }
         //otherwise if the ball collided with a brick
         else if(collider instanceof GRect) 
         {
         	     //reverse y velocity
            vy = -vy;
                 //remove the brick
            remove(collider);
            
            score.setLabel("Score: " + scoreCount);
            amountLeft.setLabel("Bricks Left: " + bricksLeft);
            
         
            //int scoreCount = 0;
           //int bricksLeft = 100;
            
            if(collider != null)
            {
               bricksLeft--;
               amountLeft.setLabel("Bricks Left: " + bricksLeft);
            }
            
            
           
           
            if(collider.getColor() == Color.CYAN)
            {
               scoreCount += 2;
               score.setLabel("Score: " + scoreCount);
            }
            
            else if(collider.getColor() == Color.GREEN)
            {
               scoreCount = scoreCount + 5;
               score.setLabel("Score: " + scoreCount);
            }
            
            else if(collider.getColor() == Color.YELLOW)
            {
               scoreCount = scoreCount + 7;
               score.setLabel("Score: " + scoreCount);
            }
            
            else if(collider.getColor() == Color.ORANGE)
            {
               scoreCount = scoreCount + 10;
               score.setLabel("Score: " + scoreCount);
            }
            
            else if(collider.getColor() == Color.RED)
            {
               scoreCount = scoreCount + 10;
               score.setLabel("Score: " + scoreCount);
            }
            
            
            
            if(bricksLeft < 1)
                {
                  GLabel winner = new GLabel("WINNER!",200,300);
                  winner.isVisible();
                  winner.setColor(Color.GREEN);
                  add(winner);
                  remove(ball);
                  
                  pause(5000);
                  
                  remove(winner);
                  
                  setup();
                  waitForClick();
                  play();
           
               
                }                      
            
            
                 
            //remove the brick
            remove(collider);
         }
      }
   }
        //getCollidingObject -- called from the playBall method
        //discovers and returns the object that the ball collided with
   private GObject getCollidingObject()
   {
      if(getElementAt(ball.getX(), ball.getY()) != null)
         return getElementAt(ball.getX(), ball.getY());
      else if(getElementAt(ball.getX()+BALL_RADIUS*2, ball.getY()) != null)
         return getElementAt(ball.getX()+BALL_RADIUS*2, ball.getY());
      else if(getElementAt(ball.getX()+BALL_RADIUS*2, ball.getY()+BALL_RADIUS*2) != null)
         return getElementAt(ball.getX()+BALL_RADIUS*2, ball.getY()+BALL_RADIUS*2);
      else if(getElementAt(ball.getX(), ball.getY()+BALL_RADIUS*2) != null)
         return getElementAt(ball.getX(), ball.getY()+BALL_RADIUS*2);
      else        
         return null;
   }
                
        //mouseMoved method -- called by the mouseListener when the mouse is moved
        //anywhere within the boundaries of the run window
   public void mouseMoved(MouseEvent e)
   {
      {
         if ((e.getX() < getWidth() - PADDLE_WIDTH/2) && (e.getX() > PADDLE_WIDTH/2)) {
            paddle.setLocation(e.getX() - PADDLE_WIDTH/2, getHeight() - PADDLE_Y_OFFSET - PADDLE_HEIGHT);
         }                
      
      
      }
   
   }
}